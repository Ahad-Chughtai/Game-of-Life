import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.*;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;

public class GamePanel extends JPanel implements MouseListener, KeyListener
{
    Main m;
    JLabel gen = new JLabel("Gen: 0");
    Color darkGray = new Color(64, 64, 64);
    int gridSquare = 700/(m.grid[0].length-2);
    boolean pause = false;

    GamePanel(Main m)
    {
        this.m = m;

        setBounds(0, 0, 700, 700);
        setBorder(BorderFactory.createLineBorder(Color.black));
        setLayout(null);

        gen.setBounds(320, 10, 100, 10);
        add(gen);

        addMouseListener(this);

        addKeyListener(this);
        setFocusable(true);
    }

    public void genChange(int genNum)
    {
        gen.setText("Gen: " + genNum);
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        drawCell(g);
    }

    public void drawCell(Graphics g)
    {
        for (int i = 0; i < m.grid.length; i++)
        {
            for (int j = 0; j < m.grid[0].length; j++)
            {
                if(i != 0 && i != 29 && j != 0 && j != 29)
                {
                    if (m.grid[i][j] == 1)
                    {
                        g.setColor(darkGray);
                        g.fillRect((j*gridSquare)-gridSquare, (i*gridSquare)-gridSquare, gridSquare, gridSquare);
                        g.setColor(Color.black);
                        g.drawRect((j*gridSquare)-gridSquare, (i*gridSquare)-gridSquare, gridSquare, gridSquare);
                    }
                    if(pause == false)
                    {
                        g.drawRect((j*gridSquare)-gridSquare, (i*gridSquare)-gridSquare, gridSquare, gridSquare);
                    }
                }
            }
        }
    }

    //MouseListener
    public void mousePressed(MouseEvent e)
    {
        if (pause == false)
        {
            int x = e.getX();
            int y = e.getY();

            if (m.grid[(y+gridSquare)/gridSquare][(x+gridSquare)/gridSquare] == 0)
            {
                m.grid[(y+gridSquare)/gridSquare][(x+gridSquare)/gridSquare] = 1;
            }
            else
            {
                m.grid[(y+gridSquare)/gridSquare][(x+gridSquare)/gridSquare] = 0;
            }

            repaint();
            //System.out.print("(" + x + ", " + y + "): " + "(" + (x+gridSquare)/gridSquare + ", " + (y+gridSquare)/gridSquare + ")\n");
        }
    }
    public void mouseReleased(MouseEvent e)
    {
    }
    public void mouseClicked(MouseEvent e)
    {
    }
    public void mouseEntered(MouseEvent e)
    {
    }
    public void mouseExited(MouseEvent e)
    {
    }

    //KeyListener
    public void keyPressed(KeyEvent e)
    {
        if (e.getKeyCode() == KeyEvent.VK_SPACE)
        {
            if(pause == false)
            {
                pause = true;
            }
            else
            {
                pause = false;
                repaint();
            }
        }
    }
    public void keyReleased(KeyEvent e)
    {
    }
    public void keyTyped(KeyEvent e)
    {
    }
}