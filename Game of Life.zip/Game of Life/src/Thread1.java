public class Thread1 extends Thread
{
    Main m;
    GamePanel gp;
    int threadSpeed = 500;
    int gen = 0;

    Thread1(GamePanel gp, Main m)
    {
        this.gp = gp;
        this.m = m;
    }

    public void run()
    {
        try
        {
            while(true)
            {
                while(m.noChange != 784 && gp.pause)
                {
                    gp.repaint();
                    m.readGrid();
                    m.grid = m.grid2;
                    m.grid2 = new int[30][30];
                    gen++;
                    gp.genChange(gen);
                    gp.repaint();
                    Thread.sleep(threadSpeed);
                }
                if (m.noChange == 784 && gp.pause)
                {
                    System.out.print("Done! Gen: " + (gen) + "\n");
                    gp.pause = false;
                    gen = 0;
                    gp.genChange(gen);
                    gp.repaint();
                    m.noChange = 0;
                }
                Thread.sleep(99);
            }
        }
        catch (Exception ex)
        {
        }
    }
}